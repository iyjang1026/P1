import sys, os
import numpy as np
from astropy.table import Table
from astropy.coordinates import SkyCoord
from astropy.wcs import WCS
import matplotlib.pyplot as plt
import astropy.io.fits as fits
from astropy.stats import sigma_clip
from masking import region_mask
from utils import radec
from astropy.visualization import simple_norm
from cpnn import Variable
import cpnn.functions as F
from cpnn import Function
import warnings
warnings.filterwarnings('ignore')

def norm(x):
    return simple_norm(x, 'linear', percent=99)

def stdz_mag(count,z_p,a):
        #mag = -2.5*np.log10(count) + z_p
        return a*count+z_p#mag

def optimizer(mag_inst, mag_cat, err_inst, z0):
    x = Variable(mag_inst)
    y = mag_cat
    W1 = Variable(np.array(0.5))
    b1 = Variable(np.array(z0))

    def predict(x):
        y = F.linear(x, W1, b1)
        return y

    lr = 0.2
    iters = 10000

    class ChiSquaredError(Function):
        def __init__(self, sigma):
            self.sigma = sigma
        def forward(self, x0, x1):
            diff = ((x0 - x1)**2)/(self.sigma**2)
            y = diff.sum() #(diff**2).sum() /len(diff)
            return y

        def backward(self, gy):
            x0, x1 = self.inputs
            diff = x0 - x1
            gx0 = gy * diff * (2 / self.sigma**2)
            gx1 = -gx0
            return gx0, gx1
        
    def chi_squared_error(x0, x1):
        return ChiSquaredError(err_inst)(x0, x1)
        
    for i in range(iters):
        y_pred = predict(x)
        loss = chi_squared_error(y, y_pred)#

        W1.cleargrad()
        b1.cleargrad()
        loss.backward()
        W1.data -= lr * W1.grad.data
        b1.data -= lr * b1.grad.data
    return W1.data, b1.data

class Phot():
    def __init__(self, path, obj,file_name, pix):
        self.path = path
        self.obj = obj
        self.file_name = file_name
        self.pix = pix
        self.data = Table.read(path+'/sky_subed/'+self.file_name+'.cat', format='ascii', converters={'obsid':str})
        self.sdss = Table.read(path + '/sdss_'+obj+'.csv', format='ascii') #check!! 
        self.hdu, self.hdr = fits.getdata(path+'/sky_subed/'+file_name+'.fits', header=True)

    def bkg_std(self,frame_size=2048, offset=15, plot=False):
        hdu = self.hdu
        hdr = self.hdr
        wcs = WCS(hdr)
        ra, dec = radec(self.obj)
        #cen_coord = get_icrs_coordinates(self.obj)#SkyCoord(ra=ra, dec=dec,frame='icrs', unit='deg')
        x,y = wcs.all_world2pix(ra, dec,0)#wcs.world_to_pixel(cen_coord)#
        std_list = []
        size = int(10/self.pix)
        area = int(frame_size - ((2*offset*60)/self.pix))
        
        croped = hdu[int(y)-area//2:int(y)+area//2, int(x)-area//2:int(x)+area//2]
        mask = np.zeros_like(hdu)
        mask[int(y)-area//2:int(y)+area//2, int(x)-area//2:int(x)+area//2] += region_mask(croped, 1, self.pix, ampglow=False)
        arr = np.where(mask!=0, np.nan, hdu)#np.ma.masked_where(mask, np.ma.masked_equal(hdu, 0))
        ran_x, ran_y = [], []
        #for i in range(1000):
        while len(std_list)<2000:
            rand_st_x = np.random.randint(x-area//2, x+area//2-size)
            rand_st_y = np.random.randint(y-area//2, y+area//2-size)
            bin_arr = arr[rand_st_y:rand_st_y+size, rand_st_x:rand_st_x+size]
            if len(bin_arr[np.isnan(bin_arr)]) <1:
                std1 = np.nanstd(bin_arr)
                std_list.append(std1)
                ran_x.append(rand_st_x)
                ran_y.append(rand_st_y)
        std_array = np.array(std_list)
        std_median = np.median(std_array)
        print(f'sigma={std_median}')
        self.bkg_noise = std_median
        if plot == True:
            hist_arr = arr[int(y)-area//2:int(y)+area//2, int(x)-area//2:int(x)+area//2]
            counts, bins = np.histogram(hist_arr, bins=64, range=(-500,500))
            width = (np.max(bins)-np.min(bins))/64
            fig, ax = plt.subplots(1,2)
            ax[0].scatter(ran_x, ran_y, s=3, c='tomato')
            ax[0].imshow(arr, norm=norm(hist_arr), origin='lower')
            ax[1].bar(bins[:-1], counts, width=width, color='C0')
            ax[1].axvline(x=np.nanmedian(hist_arr), linestyle='dashed', c='C1')
            ax[1].axvline(x=np.nanmedian(hist_arr)+std_median, linestyle='dotted', c='C1')
            ax[1].axvline(x=np.nanmedian(hist_arr)-std_median, linestyle='dotted', c='C1')
            plt.show()
        
        return std_median

    def phot_stdz(self,color, plot=False):
        data = self.data
        sdss = self.sdss
        #extract coordinate
        sdsscat = sdss['ra', 'dec', 'g','r','u', 'Err_r', 'Err_g', 'Err_u'][sdss[color]>12]
        objcat = data['ALPHAPEAK_J2000','DELTAPEAK_J2000','FLUX_BEST', 'FLUXERR_BEST']
        sdss_coord = SkyCoord(ra=sdsscat['ra'], dec=sdsscat['dec'],unit='deg', frame='fk5')
        obj_coord = SkyCoord(ra=objcat['ALPHAPEAK_J2000'], dec=objcat['DELTAPEAK_J2000'],unit='deg', frame='fk5')

        idx1, d2d1, d3d1 = sdss_coord.match_to_catalog_sky(obj_coord)
        sdss_data = sdsscat
        obj_f = objcat[idx1]

        obj_flux = obj_f['FLUX_BEST']
        fluxerr = obj_f['FLUXERR_BEST']
        sdss_mag = sdss_data[color]
        m = -2.5*np.log10(np.array(obj_flux))
        mag = np.array(sdss_mag)
        mM = mag - m
        
        z =  sigma_clip(mM, cenfunc='median', stdfunc='mad_std',sigma=3)
        t_r = m[z.mask==False]
        z0 = np.ma.median(z)
        """
        obj_magerr = obj_f['MAGERR_BEST'][zm.mask==False]
        sdss_magerr = sdss_data[str('Err_'+color)][zm.mask==False]
        mag_err = obj_magerr[z.mask==False]
        sdss_err = sdss_magerr[z.mask==False]
        """
        saturated = mag[z.mask==True]

        u = sdss_data['u']#[zm.mask==False]
        g = sdss_data['g']#[zm.mask==False]
        r = sdss_data['r']#[zm.mask==False]
        r1 = r[z.mask==False]
        g1 = g[z.mask==False]
        u1 = u[z.mask==False]

        if color == 'r':
            c = r1
            c_refer = g1
        elif color == 'g':
            c = g1
            c_refer = r1
        else :
            c = u1
            c_refer = g1
        
        print(f'# of detected stars = {len(m)}')
        print(f'Fitted star fraction = {len(mag[z.mask==False])/len(sdss_mag):.4f}')
        print(f'Saturated star fraction = {len(saturated)/len(sdss_mag):.4f}')
        
        a, zp = optimizer(t_r,mag[z.mask==False],fluxerr[z.mask==False],z0)
        def std_formular(count1,zp,a):
            return a*count1+zp
        sb_lim = zp - 2.5*np.log10(1*self.bkg_noise/(self.pix*10))
        print(f'Z_p = {zp}')
        print(f'a = {a}')
        print(f'1sigma SB Limit = {sb_lim}')

        if plot == True:
            fig,ax = plt.subplots(1,2)
            bins=32
            #counts, bins = np.histogram(mM[~np.isnan(mM)], bins=32)
            width=(np.max(bins)-np.min(bins))/32
            ax[0].hist(mM, bins=bins, color='C1')#, range=[27.7,28.3])#, width=width)
            ax[0].set_xlabel('$M - m$')
            ax[0].set_ylabel('# of stars')
            ax[0].axvline(x=zp, linestyle='dashed', linewidth=2, c='grey')
            ax[1].scatter(10**(-0.4*m),sdss_mag,s=3,c='grey')
            ax[1].scatter(10**(-0.4*t_r),mag[z.mask==False],s=2,c='r', alpha=0.5)
            
            m.sort()
            x = np.linspace(np.min(m), np.max(m), len(m))
            def line(x, a,b):
                return a*x+b
            ax[1].plot(10**(-0.4*x),line(x,a,zp),c='k',linewidth=1.5)
            ax[1].set_xscale('log', base=10)
            ax[1].set_xlabel('Flux(log10)')
            ax[1].set_ylabel(f'$\mu_{color}$')    
            ax[1].text(np.min(10**(-0.4*m))+10, np.min(sdss_mag), f'$Z_p$ = {zp:.2f}'+'\n$\mu_{limit,1\sigma}$'+f' = {sb_lim:.2f}', bbox={'boxstyle':'square', 'fc':'white'})
            ax[1].set_title(f'{color}-band SB limit of {self.obj}')
            plt.show()
        
        return a, zp, sb_lim, len(m)



def sb_limit_proc(path, obj,file_name,pix,frame_size,offset,color=str, plot=False):
    phot = Phot(path, obj,file_name,pix)
    exptime = np.array(phot.hdr['EXPTIME'], dtype=np.float32)
    std_noise = phot.bkg_std(frame_size,offset, plot=False)
    a, zp,sb_lim, num_star = phot.phot_stdz(color, plot=plot)

    #return exptime, std_noise,a, zp, sb_lim, num_star

"""
path = '~/NGC5907'
sb_limit_proc(path, 'NGC5907', 'coadd', 1.89, 2048, 20, 'r', plot=True)
"""
"""
data_list = [['obj','exptime', 'std_noise', 'a','zp', 'sb_lim', 'num_star']]    
ssd_path = '/volumes/ssd/intern/25_summer'
obj_list = ['M101','M51','NGC6946','NGC4236', 'NGC5907']
file_list = ['M101_L', 'M51_L', 'NGC6946_L','NGC4236_r','NGC5907_r']
for i in range(len(file_list)):
    exptime, std_noise,a, zp, sb_lim, num_star =sb_limit_proc(ssd_path+'/'+file_list[i], obj_list[i], 'coadd', 1.89, 2048 ,20,'r', plot=False)
    data_list.append([obj_list[i],exptime, std_noise,a, zp, sb_lim, num_star])

import csv
f = open('/Users/jang-in-yeong/phot_data_ver2.csv', 'w',newline='', encoding='ascii')
writer = csv.writer(f)
writer.writerows(data_list)
"""